<h2>Index</h2>

<div class="info">Selamat datang, <strong>Website PLN</strong></div>