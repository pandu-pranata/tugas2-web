<h2>Edit Golongan</h2>

<form action="<?php echo URL; ?>/golongan/update" method="post">
  <input type="hidden" name="gol_id" value="<?php echo $data['gol_id']; ?>">
  <table>
    <tr>
      <td>Kode</td>
      <td>
        <input type="text" value="<?php echo $data['gol_kode'] ?>" name="gol_kode">
      </td>
    </tr>
    <tr>
      <td>Nama</td>
      <td>
        <input type="text" value="<?php echo $data['gol_nama'] ?>" name="gol_nama">
      </td>
    </tr>
    <tr>
      <td></td>
      <td>
        <input type="submit" name="btn_simpan" value="UPDATE">
      </td>
    </tr>
  </table>
</form>