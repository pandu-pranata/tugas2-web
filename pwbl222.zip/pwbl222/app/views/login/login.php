<!-- <h3>Login</h3>

<form action="login_proses.php" method="POST">
  <table>
    <tr>
      <td>Username</td>
      <td><input type="text" name="i_username" required></td>
    </tr>
    <tr>
      <td>Password</td>
      <td><input type="password" name="i_password" required></td>
    </tr>
    <tr>
      <td></td>
      <td><input type="submit" name="b_login" value="Login"></td>
    </tr>
  </table>
</form> -->

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login</title>
  <link rel="shortcut icon" href="<?php echo AST; ?>/img/logo.png" type="image/x-icon">
  <link rel="stylesheet" href="<?php echo AST; ?>/css/style.css">
</head>

<body id="bg-login">
  <div class="box-login">
    <center><img src="<?php echo AST; ?>/img/logo.png" alt="" class="brand"></center>
    <h2>Login</h2>
    <form action="<?php echo URL; ?>/Log/login" method="post">
      <input type="text" name="username" placeholder="Username" class="input-control">
      <input type="password" name="password" placeholder="Password" class="input-control">
      <input type="submit" name="submit" value="Login" class="btn-login">
    </form>
  </div>
</body>

</html>