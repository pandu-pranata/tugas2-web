<?php

namespace App\Models;

use App\Core\Model;

class Log_model extends Model
{
    public function getUser($user_email, $user_password)
    {
        $query = "SELECT * FROM tb_users WHERE user_email=:user_email AND user_password=:user_password";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(":user_email", $user_email);
        $stmt->bindParam(":user_password", $user_password);
        $stmt->execute();

        return $this->resultSet($stmt);
    }
}
